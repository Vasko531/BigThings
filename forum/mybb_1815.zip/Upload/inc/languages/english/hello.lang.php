<?php
/**
 * MyBB 1.8
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 *
 */

$l['hello'] = 'Hello World!';
$l['hello_add'] = 'Add';
$l['hello_add_message'] = 'Add Message';
$l['hello_empty'] = 'No messages were found.';
$l['hello_message_empty'] = 'Message cannot be empty.';
$l['hello_done'] = 'Successfully added a new message.';